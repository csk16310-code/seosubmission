const keys = {
    public_key: "M9s1OaP6P72jJY5de"
    service_id: "service_ek7e258"
    template_id:"template_wg9v44z"
}

export default keys;